/*
 * Source-of-truth content transcribed from BRUCE MAHERO 2026.docx.
 * Keep source-reported and incomplete information explicitly labeled.
 */
window.BRUCE_CONTENT = Object.freeze({
  identity: {
    name: "Bruce Mahero",
    professionalTitle: "Innovation Journalist | Media & Communication Professional",
    location: "Nairobi, Kenya",
    documentTitle: "PERSONAL BIOGRAPHY & PROFESSIONAL MEDIA PORTFOLIO"
  },
  biography: [
    "Bruce Mahero is a prominent Kenyan journalist, media professional, digital communicator, and student leader whose work sits at the intersection of journalism, technology, information integrity, and youth leadership. He is pursuing a Bachelor's degree in Journalism at Zetech University and serves as President of the Journalism Students Association of Kenya (JSAK), leading the association's 4th Session National Executive Council.",
    "His professional interests include innovation journalism, ethical reporting, fact-checking, artificial intelligence and the media, digital communication, and the development of the next generation of journalists in Kenya. Through his academic work, editorial contributions, industry engagements, and leadership responsibilities, Bruce is building a career centred on responsible storytelling, professional collaboration, and public trust."
  ],
  personalBackground: {
    text: "Bruce Mahero is based in Nairobi, Kenya. His educational journey began at Marenyo Primary School, continued at Butere Boys High School, and led him to university-level journalism studies at Zetech University.",
  },
  education: [
    { institution: "Marenyo Primary School", details: "Bruce completed his primary education." },
    { institution: "Butere Boys High School", details: "He completed his secondary education." },
    { institution: "Zetech University", qualification: "Bachelor's degree in Journalism (pursuing)", details: "Bruce is pursuing a Bachelor's degree in Journalism, developing competencies in reporting, broadcast production, news presentation, media law and ethics, digital storytelling, and multimedia communication." }
  ],
  professionalExperience: {
    journalismAndMediaProduction: {
      overview: "Bruce is developing a multidisciplinary career in journalism, with interests spanning reporting, news anchoring, producing, editorial writing, and digital content creation. His approach combines traditional journalistic principles with the opportunities presented by digital platforms and emerging technologies.",
      areas: [
        "News reporting, interviewing, and feature writing.",
        "Broadcast production, news presentation, and multimedia storytelling.",
        "Innovation and technology journalism.",
        "Media law, ethics, verification, and accountability.",
        "Social media marketing, editorial content, and audience engagement."
      ]
    },
    digitalMediaAndEditorialWork: "Bruce has contributed to EpicPulse Magazine through social media marketing and content development. His work involves supporting online engagement, communicating stories to digital audiences, and contributing to website content. His journalism interests include examining how artificial intelligence is changing newsroom practices and how journalists can balance innovation with accuracy, human judgment, and ethical responsibility.",
    sportsJournalismAndContentCreation: "Through content work with Zetech Sparks FC, Bruce has developed experience in sports communication, including match-day captions, team announcements, player recognition, match galleries, and post-match coverage."
  },
  leadership: {
    organization: "Journalism Students Association of Kenya (JSAK)",
    role: "President, 4th Session National Executive Council",
    assumedOffice: "October 2026",
    journey: "His leadership journey progressed from representing Zetech University as a Chapter Representative to taking on national-level responsibilities.",
    responsibilities: "As President, he works with chapter representatives and the national secretariat to strengthen coordination, encourage collaboration, and support initiatives that benefit journalism students across Kenyan universities.",
    priorities: [
      "Promoting collaboration among journalism students and university chapters.",
      "Encouraging practical learning, media innovation, and professional development.",
      "Supporting student engagement with media organisations and industry practitioners.",
      "Promoting ethical journalism, fact-checking, and information integrity.",
      "Strengthening communication and coordination across the association."
    ]
  },
  engagements: [
    {
      name: "Africa Facts Summit 2026",
      dates: "21–22 October 2026",
      venue: "Safari Park Hotel, Nairobi",
      theme: "Information Integrity in an Ever-Evolving Landscape: AI, Agency, and Influence in Africa",
      details: "Bruce attended the Africa Facts Summit. The event explored misinformation, artificial intelligence, information integrity, and the responsibilities of media professionals."
    },
    {
      name: "Building Information Resilience Against FIMI in Kenya — Workshop Training I",
      dates: "29–30 June 2026",
      venue: "Mövenpick Nairobi",
      organizers: "Africa Check in partnership with the European Union External Action",
      details: "Bruce completed a two-day professional development workshop. The training focused on fact-checking, verification, and strengthening resilience against Foreign Information Manipulation and Interference (FIMI)."
    }
  ],
  publications: {
    awardWinningFeature: {
      category: "Best Feature Story",
      award: "First place at the JSAK Annual Media Awards",
      title: null,
      publication: null,
      date: null,
      directUrl: "https://epicpulse.co.ke/dennis-irungu-building-systems-africa-can-rely-on/"
    },
    authorAndPublicationLinks: {
      epicPulseMagazine: "https://epicpulse.co.ke/author/bruce-mahero/",
      dataPointDaily: "https://datapointdaily.co.ke/author/bruce-mahero",
      theBoldEastAfrica: "https://theboldeastafrica.com/author/BRUCE%20MAHERO",
      zetechUniversity: "https://www.zetech.ac.ke/"
    }
  },
  // Add only verified entries to this archive. Optional metadata stays blank
  // until it can be confirmed from the actual YouTube video metadata.
  // Each record supports title, youtubeUrl, youtubeId, description,
  // publishedDate, and thumbnail.
  mediaArchive: {
    // Decorative newsroom background supplied via the saved Pinterest Pin HTML.
    homepageBackgroundVideo: {
      playbackUrl: "https://v1.pinimg.com/videos/iht/hls/68/28/c3/6828c36824b3e9a06825dd2fb056488b.m3u8",
      poster: "images/media/newsroom-video-poster.jpg",
      sourcePage: "https://www.pinterest.com/pin/35043703347658564/"
    },
    videos: [
      {
        title: "",
        youtubeUrl: "https://youtube.com/watch?v=0k2mKFwWNM8&si=w75grYPTenzaHLod",
        youtubeId: "0k2mKFwWNM8",
        description: "",
        publishedDate: "",
        thumbnail: ""
      },
      {
        title: "",
        youtubeUrl: "https://youtube.com/watch?v=MtlBKC6pTBI&si=fKEwa9RBYn1IqqZ",
        youtubeId: "MtlBKC6pTBI",
        description: "",
        publishedDate: "",
        thumbnail: ""
      }
    ]
  },
  awardsAndCertificates: [
    {
      name: "First Place — Best Feature Story | JSAK Annual Media Awards",
      details: "Recognised for feature writing, receiving a gold medal and a certificate of appreciation while representing Zetech University."
    },
    {
      name: "Certificate of Completion — Building Information Resilience Against FIMI in Kenya, Workshop Training I",
      dates: "29–30 June 2026",
      organizers: "Africa Check in partnership with the European Union External Action",
      details: "The workshop addressed information verification, fact-checking, and resilience against foreign information manipulation and interference."
    }
  ],
  signatureQuote: "The future of journalism belongs to those who embrace innovation, uphold integrity, and remain committed to the truth.",
  quoteAttribution: "Bruce Mahero",
  vision: "Bruce aspires to contribute to the development of journalism in Kenya and across Africa by embracing innovation while defending the principles that make journalism valuable to society. He is interested in how emerging technologies can improve storytelling, strengthen verification, and expand access to reliable information without replacing human judgment or professional accountability. Through journalism, leadership, digital communication, and continued professional development, he aims to support a media environment that is credible, innovative, inclusive, and responsive to the public interest.",
  contacts: {
    email: "brucemahero@zetech.ac.ke",
    linkedin: "https://www.linkedin.com/in/bruce-mahero-034072359/",
    facebook: "https://www.facebook.com/thee.bruletz/",
    x: "https://x.com/brucemahero",
    instagram: "https://www.instagram.com/brucemahero/",
    website: null,
    youtube: null
  },
  sourceLinks: {
    nationAfricaVerificationOnly: "https://nation.africa/kenya/life-and-style/saturday-magazine/my-wife-walked-out-on-us--585424",
    zetechArticleOrEvent: "https://www.zetech.ac.ke/index.php/latest-events/empowering-learners-for-the-ai-era-through-digital-fluency-and-security-awareness",
    linkedinArticleReference: "https://lnkd.in/p/dzGXeq8J",
    awardStoryReference: "https://epicpulse.co.ke/dennis-irungu-building-systems-africa-can-rely-on/"
  },
  photographs: [
    { key: "portrait", src: "images/bruce-mahero-profile-optimized.jpg", title: "Professional portrait", alt: "Bruce Mahero in a blue suit, white shirt and blue tie", caption: "Professional portrait of Bruce Mahero" },
    { key: "award", src: "images/awards/jsak-media-award-2026.jpg", title: "JSAK Annual Media Awards", alt: "Bruce Mahero receives a certificate and medal at the JSAK Annual Media Awards.", caption: "Certificate presentation · JSAK Annual Media Awards" },
    { key: "workshop", src: "images/workshops/africa-check-fimi-workshop-2026.jpg", title: "Africa Check workshop", alt: "Bruce Mahero and an Africa Check representative hold his workshop certificate", caption: "Africa Check professional development workshop" },
    { key: "speaking", src: "images/events/bruce-mahero-speaking.jpg", title: "Bruce Mahero presenting his article", alt: "Bruce Mahero presenting his article at a lectern", caption: "Bruce Mahero presenting his article" },
    { key: "panel", src: "images/events/jsak-media-awards-panel-2026.jpg", title: "JSAK panel discussion", alt: "Five participants take part in a panel discussion at the JSAK Annual Media Awards", caption: "JSAK Annual Media Awards panel discussion" },
    { key: "summit", src: "images/events/africa-facts-summit-2026.jpg", title: "Africa Facts Summit 2026", alt: "Bruce Mahero standing in front of the Africa Facts Summit 2026 backdrop", caption: "Africa Facts Summit 2026" }
  ]
});
