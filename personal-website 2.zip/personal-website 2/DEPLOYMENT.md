# Bruce Mahero website deployment checklist

This project is a static HTML, CSS and JavaScript site. It does not currently use PHP, MySQL, a build tool, an API or a contact-form service.

## Before upload

1. Confirm the exact `.co.ke` domain and whether the preferred address uses `www`.
2. Replace `REPLACE-WITH-CONFIRMED-DOMAIN.co.ke` in `sitemap.xml` and `robots.txt` with that exact host. Do not upload the placeholder values.
3. Add a canonical link to each HTML page using the chosen HTTPS host and that page's final path. Canonical links are intentionally absent until the host is known.
4. Review the source-confirmation items in `CONTENT-CHECKLIST.md`, especially the article's outlet/date/direct URL and the award-winning feature's title, publication, date and direct URL.

## Upload through DirectAdmin

The homepage file is `index.html`. Upload `index.html`, the other five HTML pages (`about.html`, `watch-read.html`, `media.html`, `gallery.html`, and `contact.html`), `style.css`, `script.js`, `favicon.svg`, `robots.txt`, `sitemap.xml`, the complete `data` and `images` folders to the domain's document root (usually `public_html`). Preserve the folder and filenames so relative paths continue to work.

### Git deployment

If Git Deployment is enabled for the hosting account, create a Git repository for this project, commit the reviewed site files, add the hosting-provided remote, push the configured branch, and set the deployment target to the domain's document root. Confirm the host's required branch and directory in DirectAdmin before deployment. No Git remote is configured in this project yet.

### SFTP or FTP

If using a transfer client, prefer SFTP if the hosting account offers it. Upload the project files and `images` folder to the same document root. Use FTPS if only FTP-based access is available and the provider supports it. Do not put passwords or private keys in this project.

## After DNS and SSL are ready

1. Confirm DNS points the domain to the hosting account and issue/enable its Let's Encrypt certificate in DirectAdmin.
2. Open the HTTPS homepage and each page directly. Check the browser's certificate/security indicator, images, navigation, mobile menu, gallery viewer, email link and social links.
3. Confirm the non-preferred `www` or non-`www` host redirects to the chosen HTTPS host. Configure this with the hosting panel only after DNS and SSL are working.
4. Open `/robots.txt` and `/sitemap.xml` on the production host and confirm they contain the final domain.
5. Create or verify the domain property in Google Search Console, complete domain ownership verification with the DNS TXT record, submit `/sitemap.xml`, and use URL Inspection on the homepage and important pages. Indexing and search presentation are controlled by Google and are not guaranteed.

## Contact email and form

The contact page uses a `mailto:` link to `brucemahero@zetech.ac.ke`; it opens the visitor's configured email application and does not submit a message through the site. There is no contact form. A functioning form would need a configured server-side PHP mail handler or a selected third-party form service, plus spam controls and a verified delivery address.
