# Image Manifest

The six original photographs below are embedded in `BRUCE MAHERO 2026.docx`. Each extracted asset was checked against the corresponding existing project image using SHA-256; all six match byte-for-byte. Files were moved into the category folders without recompression. Website references were updated to the new paths. The existing optimized portrait derivative remains in `images/` for the current site.

| DOCX image | Filename | Original image description | Intended website section | Recommended alt text |
| --- | --- | --- | --- | --- |
| `image1.png` | `images/profile/bruce-mahero-profile.png` | Professional portrait of Bruce Mahero wearing a blue suit, white shirt and tie, against a black background. | Profile; gallery | `Bruce Mahero in a blue suit, white shirt and blue tie` |
| `image2.jpeg` | `images/awards/jsak-media-award-2026.jpg` | Bruce Mahero receives a certificate at the JSAK Annual Media Awards; he wears a medal and shakes hands with the presenter. | Awards and Recognition; gallery | `Bruce Mahero receives a certificate at the JSAK Annual Media Awards` |
| `image3.jpeg` | `images/workshops/africa-check-fimi-workshop-2026.jpg` | Bruce Mahero and a workshop representative hold his Africa Check Certificate of Completion. | Professional Development; workshops; gallery | `Bruce Mahero and an Africa Check representative hold his workshop certificate` |
| `image4.jpeg` | `images/events/bruce-mahero-speaking.jpg` | Bruce Mahero speaks into a microphone behind a lectern. | Leadership; About; homepage; events | `Bruce Mahero speaking into a microphone at a lectern` |
| `image5.jpeg` | `images/events/jsak-media-awards-panel-2026.jpg` | Panel discussion at the JSAK Annual Media Awards, with five participants seated on stage. | Leadership; Events; gallery | `Five participants take part in a panel discussion at the JSAK Annual Media Awards` |
| `image6.jpeg` | `images/events/africa-facts-summit-2026.jpg` | Bruce Mahero stands at the Africa Facts Summit 2026 backdrop. | Professional Engagements; Events; gallery | `Bruce Mahero standing in front of the Africa Facts Summit 2026 backdrop` |

These files are the source photographs. `images/bruce-mahero-profile-optimized.jpg` is an existing optimized derivative used by the current homepage and About page; it is not an additional DOCX-embedded photograph.
